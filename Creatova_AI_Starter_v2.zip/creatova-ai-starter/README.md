# Creatova AI — first backend integration

This starter connects the Creatova prototype to a server-side Gemini API endpoint. The API key stays on the server, not in browser code.

## Run locally
1. Install Node.js 20 or newer.
2. Open a terminal in this folder and run `npm install`.
3. Copy `.env.example` to `.env` and paste your Gemini API key.
4. Run `npm start` and open `http://localhost:3000`.

Get a key from Google AI Studio: https://aistudio.google.com/app/apikey
The Gemini API has a free tier for certain models/accounts, subject to limits. Do not enable billing unless you choose to. Without a key, the app will show an honest setup message instead of fake AI output.

## Not production-ready yet
Authentication, database, subscription billing, per-user quotas, moderation, monitoring and deployment still need to be added before public launch. Never upload `.env` or share your API key.
